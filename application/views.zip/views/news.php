<!-- banner -->
<section>
    <div class="image-container">
        <img src="assets/img/Newsbanner.png" alt="Banner Image" style="width: 100%;height: 80vh;">
        <div class="overlay"></div>
        <p class="bannerH3">NEWS</p>

    </div>
</section>

<!-- updates -->
<section>
    <div class="container space-y">
        <div class="row d-flex justify-content-around mspace ">
            <div class="col-md-5">
                <h5 class="tag1"> latest</h5>
            </div>
            <div class="col-md-5"></div>


            <div class="col-md-5">
                <h5 class="tag2">updates</h5>
            </div>
            <div class="col-md-5"></div>
        </div>

        <div class="row d-flex justify-content-around space">

            <div class="col-md-12">
                <img src="assets/img/soon.png" alt="" style="width: 100%;">
            </div>



        </div>

        <!-- 
            <div class="row d-flex justify-content-around space">

                <div class="col-md-5 text-center card shadow p-0 pb-4">
                    <img src="assets/img/project1.png" alt="" class="p">
                    <p class="pt-4" style="color: #1A406D;" >2024-07-10  |   By John Smith, Senior Correspondent</p>
                    <p class="uHeading">ADMOG Holding Unveils New Refinery Expansion Plans </p>
                    <p class="corporate px-5">ADMOG Holding has announced an ambitious expansion of its refinery operations to meet growing global demand for high-quality metals. The new project aims to increase production capacity by 30% while incorporating cutting-edge technology to enhance efficiency and sustainability.</p>
                    <div class="row py-4  d-flex justify-content-center" >
                        <div class="col-md-4">
                        <a class="blue" href="">
                            KNOW MORE
                        </a>
                    </div>
                    </div>

                </div>

                <div class="col-md-5 text-center card shadow p-0 pb-4">
                    <img src="assets/img/project1.png" alt="" class="p">
                    <p class="pt-4" style="color: #1A406D;" >2024-07-10  |   By John Smith, Senior Correspondent</p>
                    <p class="uHeading">ADMOG Holding Unveils New Refinery Expansion Plans </p>
                    <p class="corporate px-5">ADMOG Holding has announced an ambitious expansion of its refinery operations to meet growing global demand for high-quality metals. The new project aims to increase production capacity by 30% while incorporating cutting-edge technology to enhance efficiency and sustainability.</p>
                    <div class="row py-4  d-flex justify-content-center" >
                        <div class="col-md-4">
                        <a class="blue" href="">
                            KNOW MORE
                        </a>
                    </div>
                    </div>

                </div>
            </div>
            
            <div class="row d-flex justify-content-around space">
                <div class="col-md-5 text-center card shadow p-0 pb-4">
                    <img src="assets/img/project1.png" alt="" class="p">
                    <p class="pt-4" style="color: #1A406D;" >2024-07-10  |   By John Smith, Senior Correspondent</p>
                    <p class="uHeading">ADMOG Holding Unveils New Refinery Expansion Plans </p>
                    <p class="corporate px-5">ADMOG Holding has announced an ambitious expansion of its refinery operations to meet growing global demand for high-quality metals. The new project aims to increase production capacity by 30% while incorporating cutting-edge technology to enhance efficiency and sustainability.</p>
                    <div class="row py-4  d-flex justify-content-center" >
                        <div class="col-md-4">
                        <a class="blue" href="">
                            KNOW MORE
                        </a>
                    </div>
                    </div>

                </div>

                <div class="col-md-5 text-center card shadow p-0 pb-4">
                    <img src="assets/img/project1.png" alt="" class="p">
                    <p class="pt-4" style="color: #1A406D;" >2024-07-10  |   By John Smith, Senior Correspondent</p>
                    <p class="uHeading">ADMOG Holding Unveils New Refinery Expansion Plans </p>
                    <p class="corporate px-5">ADMOG Holding has announced an ambitious expansion of its refinery operations to meet growing global demand for high-quality metals. The new project aims to increase production capacity by 30% while incorporating cutting-edge technology to enhance efficiency and sustainability.</p>
                    <div class="row py-4  d-flex justify-content-center" >
                        <div class="col-md-4">
                        <a class="blue" href="">
                            KNOW MORE
                        </a>
                    </div>
                    </div>

                </div>


            </div>

            <div class="row d-flex justify-content-around space">

                <div class="col-md-5 text-center card shadow p-0 pb-4">
                    <img src="assets/img/project1.png" alt="" class="p">
                    <p class="pt-4" style="color: #1A406D;" >2024-07-10  |   By John Smith, Senior Correspondent</p>
                    <p class="uHeading">ADMOG Holding Unveils New Refinery Expansion Plans </p>
                    <p class="corporate px-5">ADMOG Holding has announced an ambitious expansion of its refinery operations to meet growing global demand for high-quality metals. The new project aims to increase production capacity by 30% while incorporating cutting-edge technology to enhance efficiency and sustainability.</p>
                    <div class="row py-4  d-flex justify-content-center" >
                        <div class="col-md-4">
                        <a class="blue" href="">
                            KNOW MORE
                        </a>
                    </div>
                    </div>

                </div>

                <div class="col-md-5 text-center card shadow p-0 pb-4">
                    <img src="assets/img/project1.png" alt="" class="p">
                    <p class="pt-4" style="color: #1A406D;" >2024-07-10  |   By John Smith, Senior Correspondent</p>
                    <p class="uHeading">ADMOG Holding Unveils New Refinery Expansion Plans </p>
                    <p class="corporate px-5">ADMOG Holding has announced an ambitious expansion of its refinery operations to meet growing global demand for high-quality metals. The new project aims to increase production capacity by 30% while incorporating cutting-edge technology to enhance efficiency and sustainability.</p>
                    <div class="row py-4  d-flex justify-content-center" >
                        <div class="col-md-4">
                        <a class="blue" href="">
                            KNOW MORE
                        </a>
                    </div>
                    </div>

                </div>


            </div> -->

    </div>
</section>
<!--  updates  -->

<!-- started -->
<section>
    <div class="banner-container ">
        <img src="assets/img/blue-banner.png" alt="" class="banner-image" style="height: 60vh;">
        <div class="banner-content blue-banner  ">
            <p class="j-bannerH1 j1" >lETS GET YOUR PROJECT STARTED</p>
            <p class="j-bannerH1 j2 pt-3 pb-5">
                To learn more about our services or to discuss potential partnerships, please contact us. Our team is
                ready to assist you with any inquiries you may have.
            </p>
            <a class="htop wTop" href="Contact" style="font-size: 19px;">Contact us</a>
        </div>
    </div>

</section>