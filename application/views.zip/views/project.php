<!-- banner -->
<section>
    <div class="image-container">
        <img src="assets/img/Projectsbanner.png" alt="Banner Image" style="width: 100%;height: 80vh;">
        <div class="overlay"></div>
        <p class="bannerH3">Projects</p>

    </div>
</section>

<!-- key projects -->
<section>
        <div class="container space-y">
            <div class="row d-flex justify-content-around mspace">
                <div class="col-md-5">
                    <h5 class="tag1"> key</h5>
                </div>
                <div class="col-md-5"></div>


                <div class="col-md-5">
                    <h5 class="tag2">Projects</h5>
                </div>
                <div class="col-md-5"></div>
            </div>



            <div class="row d-flex justify-content-around space">

                <div class="col-md-5 pictures">
                    <img src="assets/img/soon.png" alt="" class="soon">
                </div>

                <div class="col-md-5 pictures">
                    <img src="assets/img/soon.png" alt="" class="soon">
                    <!-- <p class="p-para ">Situated in [Region], this initiative targets [specific metal or resource]. Our
                        preliminary exploration results indicate substantial deposits, positioning it as a future
                        flagship operation.</p>
                    <div class="row" style="padding-left: 16px;">
                        <a class="htop blue-white col-md-4 " href="">
                            see details
                        </a> 
                    </div>-->
                </div>

            </div>

        </div>
    </section>

<!-- started -->
<section>
    <div class="banner-container ">
        <img src="assets/img/blue-banner.png" alt="" class="banner-image" style="height: 60vh;">
        <div class="banner-content blue-banner  ">
            <p class="j-bannerH1 j1" >lETS GET YOUR PROJECT STARTED</p>
            <p class="j-bannerH1 j2 pt-3 pb-5">
                To learn more about our services or to discuss potential partnerships, please contact us. Our team is
                ready to assist you with any inquiries you may have.
            </p>
            <a class="htop wTop" href="Contact" style="font-size: 19px;">Contact us</a>
        </div>
    </div>

</section>